﻿/*Licensed Materials - Property of IBM

5725-C15

© Copyright IBM Corp. 1994, 2013 All Rights Reserved

US Government Users Restricted Rights - Use, duplication or
disclosure restricted by GSA ADP Schedule Contract with
IBM Corp.
*/

namespace Client
{
    partial class Client
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCreateBatch = new System.Windows.Forms.Button();
            this.lblApplicationName = new System.Windows.Forms.Label();
            this.tbApplication = new System.Windows.Forms.TextBox();
            this.tbUri = new System.Windows.Forms.TextBox();
            this.lblServerAddress = new System.Windows.Forms.Label();
            this.tbJob = new System.Windows.Forms.TextBox();
            this.lblJobName = new System.Windows.Forms.Label();
            this.lblQueueID = new System.Windows.Forms.Label();
            this.tbQueueID = new System.Windows.Forms.TextBox();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.tbImagesFolder = new System.Windows.Forms.TextBox();
            this.lblImagesFolder = new System.Windows.Forms.Label();
            this.btnUpload = new System.Windows.Forms.Button();
            this.btnReleaseBatch = new System.Windows.Forms.Button();
            this.btnGrabBatch = new System.Windows.Forms.Button();
            this.comboBoxDocs = new System.Windows.Forms.ComboBox();
            this.comboBoxPages = new System.Windows.Forms.ComboBox();
            this.lblPageName = new System.Windows.Forms.Label();
            this.tbFieldValue = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.snippet = new System.Windows.Forms.PictureBox();
            this.btnComplete = new System.Windows.Forms.Button();
            this.tbResponseStatus = new System.Windows.Forms.TextBox();
            this.lblResponseStatus = new System.Windows.Forms.Label();
            this.lblDocs = new System.Windows.Forms.Label();
            this.lblPage = new System.Windows.Forms.Label();
            this.lblImageFile = new System.Windows.Forms.Label();
            this.lblBatchID = new System.Windows.Forms.Label();
            this.tbBatchID = new System.Windows.Forms.TextBox();
            this.btnGetBatchID = new System.Windows.Forms.Button();
            this.tbDataFile = new System.Windows.Forms.TextBox();
            this.tbPageImageName = new System.Windows.Forms.TextBox();
            this.lblDataFile = new System.Windows.Forms.Label();
            this.btnLoadImageFile = new System.Windows.Forms.Button();
            this.comboBoxFields = new System.Windows.Forms.ComboBox();
            this.tbFieldPosition = new System.Windows.Forms.TextBox();
            this.gbBatchCreation = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblFieldPosition = new System.Windows.Forms.Label();
            this.lblFieldText = new System.Windows.Forms.Label();
            this.lblFields = new System.Windows.Forms.Label();
            this.lblPageFileName = new System.Windows.Forms.Label();
            this.tbPageFileName = new System.Windows.Forms.TextBox();
            this.lblSnippet = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblResponseMessage = new System.Windows.Forms.Label();
            this.tbResponseMessage = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.snippet)).BeginInit();
            this.gbBatchCreation.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCreateBatch
            // 
            this.btnCreateBatch.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.btnCreateBatch.Location = new System.Drawing.Point(412, 28);
            this.btnCreateBatch.Name = "btnCreateBatch";
            this.btnCreateBatch.Size = new System.Drawing.Size(127, 21);
            this.btnCreateBatch.TabIndex = 4;
            this.btnCreateBatch.Text = "Create Batch";
            this.btnCreateBatch.UseVisualStyleBackColor = true;
            this.btnCreateBatch.Click += new System.EventHandler(this.BtnCreateBatchClick);
            // 
            // lblApplicationName
            // 
            this.lblApplicationName.AutoSize = true;
            this.lblApplicationName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lblApplicationName.Location = new System.Drawing.Point(11, 54);
            this.lblApplicationName.Name = "lblApplicationName";
            this.lblApplicationName.Size = new System.Drawing.Size(59, 13);
            this.lblApplicationName.TabIndex = 1;
            this.lblApplicationName.Text = "Application";
            // 
            // tbApplication
            // 
            this.tbApplication.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.tbApplication.Location = new System.Drawing.Point(116, 52);
            this.tbApplication.Name = "tbApplication";
            this.tbApplication.Size = new System.Drawing.Size(278, 20);
            this.tbApplication.TabIndex = 5;
            this.tbApplication.Text = "FastApp";
            // 
            // tbUri
            // 
            this.tbUri.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.tbUri.Location = new System.Drawing.Point(116, 29);
            this.tbUri.Name = "tbUri";
            this.tbUri.Size = new System.Drawing.Size(278, 20);
            this.tbUri.TabIndex = 3;
            this.tbUri.Text = "http://localhost:55287/ServicewTM.svc";
            // 
            // lblServerAddress
            // 
            this.lblServerAddress.AutoSize = true;
            this.lblServerAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lblServerAddress.Location = new System.Drawing.Point(11, 32);
            this.lblServerAddress.Name = "lblServerAddress";
            this.lblServerAddress.Size = new System.Drawing.Size(79, 13);
            this.lblServerAddress.TabIndex = 4;
            this.lblServerAddress.Text = "Server Address";
            // 
            // tbJob
            // 
            this.tbJob.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.tbJob.Location = new System.Drawing.Point(116, 75);
            this.tbJob.Name = "tbJob";
            this.tbJob.Size = new System.Drawing.Size(278, 20);
            this.tbJob.TabIndex = 6;
            this.tbJob.Text = "Main Job";
            // 
            // lblJobName
            // 
            this.lblJobName.AutoSize = true;
            this.lblJobName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lblJobName.Location = new System.Drawing.Point(11, 76);
            this.lblJobName.Name = "lblJobName";
            this.lblJobName.Size = new System.Drawing.Size(55, 13);
            this.lblJobName.TabIndex = 6;
            this.lblJobName.Text = "Job Name";
            // 
            // lblQueueID
            // 
            this.lblQueueID.AutoSize = true;
            this.lblQueueID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQueueID.Location = new System.Drawing.Point(14, 30);
            this.lblQueueID.Name = "lblQueueID";
            this.lblQueueID.Size = new System.Drawing.Size(53, 13);
            this.lblQueueID.TabIndex = 7;
            this.lblQueueID.Text = "Queue ID";
            // 
            // tbQueueID
            // 
            this.tbQueueID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.tbQueueID.Location = new System.Drawing.Point(116, 27);
            this.tbQueueID.Name = "tbQueueID";
            this.tbQueueID.Size = new System.Drawing.Size(278, 20);
            this.tbQueueID.TabIndex = 13;
            // 
            // btnBrowse
            // 
            this.btnBrowse.Enabled = false;
            this.btnBrowse.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.btnBrowse.Location = new System.Drawing.Point(412, 97);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(52, 21);
            this.btnBrowse.TabIndex = 8;
            this.btnBrowse.Text = "Browse";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.BtnBrowseClick);
            // 
            // tbImagesFolder
            // 
            this.tbImagesFolder.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.tbImagesFolder.Location = new System.Drawing.Point(116, 98);
            this.tbImagesFolder.Name = "tbImagesFolder";
            this.tbImagesFolder.Size = new System.Drawing.Size(278, 20);
            this.tbImagesFolder.TabIndex = 7;
            this.tbImagesFolder.Text = "C:\\Datacap\\FastApp\\images\\wTM";
            // 
            // lblImagesFolder
            // 
            this.lblImagesFolder.AutoSize = true;
            this.lblImagesFolder.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lblImagesFolder.Location = new System.Drawing.Point(11, 98);
            this.lblImagesFolder.Name = "lblImagesFolder";
            this.lblImagesFolder.Size = new System.Drawing.Size(73, 13);
            this.lblImagesFolder.TabIndex = 11;
            this.lblImagesFolder.Text = "Images Folder";
            // 
            // btnUpload
            // 
            this.btnUpload.Enabled = false;
            this.btnUpload.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.btnUpload.Location = new System.Drawing.Point(470, 97);
            this.btnUpload.Name = "btnUpload";
            this.btnUpload.Size = new System.Drawing.Size(69, 21);
            this.btnUpload.TabIndex = 9;
            this.btnUpload.Text = "Upload";
            this.btnUpload.UseVisualStyleBackColor = true;
            this.btnUpload.Click += new System.EventHandler(this.BtnUpload);
            // 
            // btnReleaseBatch
            // 
            this.btnReleaseBatch.Enabled = false;
            this.btnReleaseBatch.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.btnReleaseBatch.Location = new System.Drawing.Point(412, 124);
            this.btnReleaseBatch.Name = "btnReleaseBatch";
            this.btnReleaseBatch.Size = new System.Drawing.Size(127, 21);
            this.btnReleaseBatch.TabIndex = 10;
            this.btnReleaseBatch.Text = "Release Batch";
            this.btnReleaseBatch.UseVisualStyleBackColor = true;
            this.btnReleaseBatch.Click += new System.EventHandler(this.BtnReleaseBatchClick);
            // 
            // btnGrabBatch
            // 
            this.btnGrabBatch.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.btnGrabBatch.Location = new System.Drawing.Point(412, 21);
            this.btnGrabBatch.Name = "btnGrabBatch";
            this.btnGrabBatch.Size = new System.Drawing.Size(127, 21);
            this.btnGrabBatch.TabIndex = 17;
            this.btnGrabBatch.Text = "Grab Batch";
            this.btnGrabBatch.UseVisualStyleBackColor = true;
            this.btnGrabBatch.Click += new System.EventHandler(this.BtnGrabBatchClick);
            // 
            // comboBoxDocs
            // 
            this.comboBoxDocs.Enabled = false;
            this.comboBoxDocs.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxDocs.FormattingEnabled = true;
            this.comboBoxDocs.ItemHeight = 13;
            this.comboBoxDocs.Location = new System.Drawing.Point(116, 75);
            this.comboBoxDocs.Name = "comboBoxDocs";
            this.comboBoxDocs.Size = new System.Drawing.Size(278, 21);
            this.comboBoxDocs.TabIndex = 19;
            this.comboBoxDocs.SelectedIndexChanged += new System.EventHandler(this.GetPages);
            // 
            // comboBoxPages
            // 
            this.comboBoxPages.Enabled = false;
            this.comboBoxPages.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxPages.FormattingEnabled = true;
            this.comboBoxPages.Location = new System.Drawing.Point(116, 101);
            this.comboBoxPages.Name = "comboBoxPages";
            this.comboBoxPages.Size = new System.Drawing.Size(278, 21);
            this.comboBoxPages.TabIndex = 20;
            this.comboBoxPages.SelectedIndexChanged += new System.EventHandler(this.GetPageDataFileName);
            // 
            // lblPageName
            // 
            this.lblPageName.AutoSize = true;
            this.lblPageName.Location = new System.Drawing.Point(309, 470);
            this.lblPageName.Name = "lblPageName";
            this.lblPageName.Size = new System.Drawing.Size(0, 13);
            this.lblPageName.TabIndex = 27;
            // 
            // tbFieldValue
            // 
            this.tbFieldValue.Enabled = false;
            this.tbFieldValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbFieldValue.Location = new System.Drawing.Point(116, 200);
            this.tbFieldValue.Name = "tbFieldValue";
            this.tbFieldValue.Size = new System.Drawing.Size(278, 20);
            this.tbFieldValue.TabIndex = 25;
            // 
            // btnSave
            // 
            this.btnSave.Enabled = false;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.btnSave.Location = new System.Drawing.Point(412, 199);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(127, 21);
            this.btnSave.TabIndex = 26;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.BtnSaveClick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.Control;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(580, 171);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(416, 553);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 36;
            this.pictureBox1.TabStop = false;
            // 
            // snippet
            // 
            this.snippet.BackColor = System.Drawing.SystemColors.ControlLight;
            this.snippet.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.snippet.Location = new System.Drawing.Point(116, 248);
            this.snippet.Name = "snippet";
            this.snippet.Size = new System.Drawing.Size(278, 64);
            this.snippet.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.snippet.TabIndex = 37;
            this.snippet.TabStop = false;
            // 
            // btnComplete
            // 
            this.btnComplete.Enabled = false;
            this.btnComplete.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.btnComplete.Location = new System.Drawing.Point(412, 244);
            this.btnComplete.Name = "btnComplete";
            this.btnComplete.Size = new System.Drawing.Size(127, 21);
            this.btnComplete.TabIndex = 28;
            this.btnComplete.Text = "Complete Batch";
            this.btnComplete.UseVisualStyleBackColor = true;
            this.btnComplete.Click += new System.EventHandler(this.BtnCompleteClick);
            // 
            // tbResponseStatus
            // 
            this.tbResponseStatus.Location = new System.Drawing.Point(15, 30);
            this.tbResponseStatus.Name = "tbResponseStatus";
            this.tbResponseStatus.ReadOnly = true;
            this.tbResponseStatus.Size = new System.Drawing.Size(93, 20);
            this.tbResponseStatus.TabIndex = 1;
            this.tbResponseStatus.TabStop = false;
            // 
            // lblResponseStatus
            // 
            this.lblResponseStatus.AutoSize = true;
            this.lblResponseStatus.Location = new System.Drawing.Point(12, 14);
            this.lblResponseStatus.Name = "lblResponseStatus";
            this.lblResponseStatus.Size = new System.Drawing.Size(88, 13);
            this.lblResponseStatus.TabIndex = 46;
            this.lblResponseStatus.Text = "Response Status";
            // 
            // lblDocs
            // 
            this.lblDocs.AutoSize = true;
            this.lblDocs.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDocs.Location = new System.Drawing.Point(14, 79);
            this.lblDocs.Name = "lblDocs";
            this.lblDocs.Size = new System.Drawing.Size(56, 13);
            this.lblDocs.TabIndex = 52;
            this.lblDocs.Text = "Document";
            // 
            // lblPage
            // 
            this.lblPage.AutoSize = true;
            this.lblPage.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPage.Location = new System.Drawing.Point(14, 104);
            this.lblPage.Name = "lblPage";
            this.lblPage.Size = new System.Drawing.Size(32, 13);
            this.lblPage.TabIndex = 59;
            this.lblPage.Text = "Page";
            // 
            // lblImageFile
            // 
            this.lblImageFile.AutoSize = true;
            this.lblImageFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblImageFile.Location = new System.Drawing.Point(14, 154);
            this.lblImageFile.Name = "lblImageFile";
            this.lblImageFile.Size = new System.Drawing.Size(55, 13);
            this.lblImageFile.TabIndex = 62;
            this.lblImageFile.Text = "Image File";
            // 
            // lblBatchID
            // 
            this.lblBatchID.AutoSize = true;
            this.lblBatchID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lblBatchID.Location = new System.Drawing.Point(14, 56);
            this.lblBatchID.Name = "lblBatchID";
            this.lblBatchID.Size = new System.Drawing.Size(49, 13);
            this.lblBatchID.TabIndex = 64;
            this.lblBatchID.Text = "Batch ID";
            // 
            // tbBatchID
            // 
            this.tbBatchID.Enabled = false;
            this.tbBatchID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.tbBatchID.Location = new System.Drawing.Point(116, 53);
            this.tbBatchID.Name = "tbBatchID";
            this.tbBatchID.Size = new System.Drawing.Size(278, 20);
            this.tbBatchID.TabIndex = 11;
            // 
            // btnGetBatchID
            // 
            this.btnGetBatchID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.btnGetBatchID.Location = new System.Drawing.Point(412, 52);
            this.btnGetBatchID.Name = "btnGetBatchID";
            this.btnGetBatchID.Size = new System.Drawing.Size(127, 21);
            this.btnGetBatchID.TabIndex = 12;
            this.btnGetBatchID.Text = "Get BatchID";
            this.btnGetBatchID.UseVisualStyleBackColor = true;
            this.btnGetBatchID.Click += new System.EventHandler(this.BtnGetBatchIDClick);
            // 
            // tbDataFile
            // 
            this.tbDataFile.Enabled = false;
            this.tbDataFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbDataFile.Location = new System.Drawing.Point(116, 127);
            this.tbDataFile.Name = "tbDataFile";
            this.tbDataFile.Size = new System.Drawing.Size(278, 20);
            this.tbDataFile.TabIndex = 21;
            this.tbDataFile.TextChanged += new System.EventHandler(this.GetPageImageName);
            // 
            // tbPageImageName
            // 
            this.tbPageImageName.Enabled = false;
            this.tbPageImageName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbPageImageName.Location = new System.Drawing.Point(116, 151);
            this.tbPageImageName.Name = "tbPageImageName";
            this.tbPageImageName.Size = new System.Drawing.Size(278, 20);
            this.tbPageImageName.TabIndex = 22;
            // 
            // lblDataFile
            // 
            this.lblDataFile.AutoSize = true;
            this.lblDataFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDataFile.Location = new System.Drawing.Point(14, 130);
            this.lblDataFile.Name = "lblDataFile";
            this.lblDataFile.Size = new System.Drawing.Size(43, 13);
            this.lblDataFile.TabIndex = 70;
            this.lblDataFile.Text = "Datafile";
            // 
            // btnLoadImageFile
            // 
            this.btnLoadImageFile.Enabled = false;
            this.btnLoadImageFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.btnLoadImageFile.Location = new System.Drawing.Point(412, 174);
            this.btnLoadImageFile.Name = "btnLoadImageFile";
            this.btnLoadImageFile.Size = new System.Drawing.Size(127, 21);
            this.btnLoadImageFile.TabIndex = 23;
            this.btnLoadImageFile.Text = "Load Image";
            this.btnLoadImageFile.UseVisualStyleBackColor = true;
            this.btnLoadImageFile.Click += new System.EventHandler(this.BtnLoadImageFileClick);
            // 
            // comboBoxFields
            // 
            this.comboBoxFields.Enabled = false;
            this.comboBoxFields.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxFields.FormattingEnabled = true;
            this.comboBoxFields.Location = new System.Drawing.Point(116, 175);
            this.comboBoxFields.Name = "comboBoxFields";
            this.comboBoxFields.Size = new System.Drawing.Size(278, 21);
            this.comboBoxFields.TabIndex = 24;
            this.comboBoxFields.SelectedIndexChanged += new System.EventHandler(this.GetFieldValue);
            // 
            // tbFieldPosition
            // 
            this.tbFieldPosition.Enabled = false;
            this.tbFieldPosition.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbFieldPosition.Location = new System.Drawing.Point(116, 224);
            this.tbFieldPosition.Name = "tbFieldPosition";
            this.tbFieldPosition.Size = new System.Drawing.Size(278, 20);
            this.tbFieldPosition.TabIndex = 27;
            this.tbFieldPosition.TextChanged += new System.EventHandler(this.FieldPositionTextChanged);
            // 
            // gbBatchCreation
            // 
            this.gbBatchCreation.Controls.Add(this.btnUpload);
            this.gbBatchCreation.Controls.Add(this.btnReleaseBatch);
            this.gbBatchCreation.Controls.Add(this.btnCreateBatch);
            this.gbBatchCreation.Controls.Add(this.btnBrowse);
            this.gbBatchCreation.Controls.Add(this.tbJob);
            this.gbBatchCreation.Controls.Add(this.tbUri);
            this.gbBatchCreation.Controls.Add(this.tbApplication);
            this.gbBatchCreation.Controls.Add(this.lblJobName);
            this.gbBatchCreation.Controls.Add(this.lblImagesFolder);
            this.gbBatchCreation.Controls.Add(this.lblApplicationName);
            this.gbBatchCreation.Controls.Add(this.tbImagesFolder);
            this.gbBatchCreation.Controls.Add(this.lblServerAddress);
            this.gbBatchCreation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbBatchCreation.Location = new System.Drawing.Point(12, 162);
            this.gbBatchCreation.Name = "gbBatchCreation";
            this.gbBatchCreation.Size = new System.Drawing.Size(552, 146);
            this.gbBatchCreation.TabIndex = 77;
            this.gbBatchCreation.TabStop = false;
            this.gbBatchCreation.Text = "Batch Creation";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblQueueID);
            this.groupBox1.Controls.Add(this.tbQueueID);
            this.groupBox1.Controls.Add(this.btnGetBatchID);
            this.groupBox1.Controls.Add(this.lblBatchID);
            this.groupBox1.Controls.Add(this.tbBatchID);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(12, 314);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(552, 80);
            this.groupBox1.TabIndex = 78;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Batch Details";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.Window;
            this.groupBox2.Controls.Add(this.lblFieldPosition);
            this.groupBox2.Controls.Add(this.lblFieldText);
            this.groupBox2.Controls.Add(this.lblFields);
            this.groupBox2.Controls.Add(this.lblPageFileName);
            this.groupBox2.Controls.Add(this.tbFieldPosition);
            this.groupBox2.Controls.Add(this.comboBoxFields);
            this.groupBox2.Controls.Add(this.lblDataFile);
            this.groupBox2.Controls.Add(this.btnSave);
            this.groupBox2.Controls.Add(this.btnGrabBatch);
            this.groupBox2.Controls.Add(this.tbPageImageName);
            this.groupBox2.Controls.Add(this.lblImageFile);
            this.groupBox2.Controls.Add(this.tbDataFile);
            this.groupBox2.Controls.Add(this.tbFieldValue);
            this.groupBox2.Controls.Add(this.tbPageFileName);
            this.groupBox2.Controls.Add(this.snippet);
            this.groupBox2.Controls.Add(this.btnLoadImageFile);
            this.groupBox2.Controls.Add(this.btnComplete);
            this.groupBox2.Controls.Add(this.lblSnippet);
            this.groupBox2.Controls.Add(this.lblDocs);
            this.groupBox2.Controls.Add(this.lblPage);
            this.groupBox2.Controls.Add(this.comboBoxPages);
            this.groupBox2.Controls.Add(this.comboBoxDocs);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(12, 400);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(552, 324);
            this.groupBox2.TabIndex = 79;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Process Task";
            // 
            // lblFieldPosition
            // 
            this.lblFieldPosition.AutoSize = true;
            this.lblFieldPosition.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFieldPosition.Location = new System.Drawing.Point(14, 227);
            this.lblFieldPosition.Name = "lblFieldPosition";
            this.lblFieldPosition.Size = new System.Drawing.Size(69, 13);
            this.lblFieldPosition.TabIndex = 84;
            this.lblFieldPosition.Text = "Field Position";
            // 
            // lblFieldText
            // 
            this.lblFieldText.AutoSize = true;
            this.lblFieldText.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFieldText.Location = new System.Drawing.Point(14, 203);
            this.lblFieldText.Name = "lblFieldText";
            this.lblFieldText.Size = new System.Drawing.Size(53, 13);
            this.lblFieldText.TabIndex = 82;
            this.lblFieldText.Text = "Field Text";
            // 
            // lblFields
            // 
            this.lblFields.AutoSize = true;
            this.lblFields.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFields.Location = new System.Drawing.Point(14, 178);
            this.lblFields.Name = "lblFields";
            this.lblFields.Size = new System.Drawing.Size(34, 13);
            this.lblFields.TabIndex = 83;
            this.lblFields.Text = "Fields";
            // 
            // lblPageFileName
            // 
            this.lblPageFileName.AutoSize = true;
            this.lblPageFileName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPageFileName.Location = new System.Drawing.Point(14, 52);
            this.lblPageFileName.Name = "lblPageFileName";
            this.lblPageFileName.Size = new System.Drawing.Size(82, 13);
            this.lblPageFileName.TabIndex = 81;
            this.lblPageFileName.Text = "Page File Name";
            // 
            // tbPageFileName
            // 
            this.tbPageFileName.Enabled = false;
            this.tbPageFileName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbPageFileName.Location = new System.Drawing.Point(116, 49);
            this.tbPageFileName.Name = "tbPageFileName";
            this.tbPageFileName.Size = new System.Drawing.Size(278, 20);
            this.tbPageFileName.TabIndex = 14;
            // 
            // lblSnippet
            // 
            this.lblSnippet.AutoSize = true;
            this.lblSnippet.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSnippet.Location = new System.Drawing.Point(14, 248);
            this.lblSnippet.Name = "lblSnippet";
            this.lblSnippet.Size = new System.Drawing.Size(43, 13);
            this.lblSnippet.TabIndex = 42;
            this.lblSnippet.Text = "Snippet";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 646);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 13);
            this.label2.TabIndex = 43;
            // 
            // lblResponseMessage
            // 
            this.lblResponseMessage.AutoSize = true;
            this.lblResponseMessage.Location = new System.Drawing.Point(125, 14);
            this.lblResponseMessage.Name = "lblResponseMessage";
            this.lblResponseMessage.Size = new System.Drawing.Size(101, 13);
            this.lblResponseMessage.TabIndex = 81;
            this.lblResponseMessage.Text = "Response Message";
            // 
            // tbResponseMessage
            // 
            this.tbResponseMessage.Location = new System.Drawing.Point(128, 39);
            this.tbResponseMessage.Multiline = true;
            this.tbResponseMessage.Name = "tbResponseMessage";
            this.tbResponseMessage.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbResponseMessage.Size = new System.Drawing.Size(868, 126);
            this.tbResponseMessage.TabIndex = 2;
            this.tbResponseMessage.TabStop = false;
            this.tbResponseMessage.WordWrap = false;
            // 
            // Client
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1008, 730);
            this.Controls.Add(this.tbResponseMessage);
            this.Controls.Add(this.lblResponseMessage);
            this.Controls.Add(this.tbResponseStatus);
            this.Controls.Add(this.lblResponseStatus);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lblPageName);
            this.Controls.Add(this.gbBatchCreation);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Name = "Client";
            this.Text = "IBM Datacap Taskmaster Webservices Test Client";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.snippet)).EndInit();
            this.gbBatchCreation.ResumeLayout(false);
            this.gbBatchCreation.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCreateBatch;
        private System.Windows.Forms.Label lblApplicationName;
        private System.Windows.Forms.TextBox tbApplication;
        private System.Windows.Forms.TextBox tbUri;
        private System.Windows.Forms.Label lblServerAddress;
        private System.Windows.Forms.TextBox tbJob;
        private System.Windows.Forms.Label lblJobName;
        private System.Windows.Forms.Label lblQueueID;
        private System.Windows.Forms.TextBox tbQueueID;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.TextBox tbImagesFolder;
        private System.Windows.Forms.Label lblImagesFolder;
        private System.Windows.Forms.Button btnUpload;
        private System.Windows.Forms.Button btnReleaseBatch;
        private System.Windows.Forms.Button btnGrabBatch;
        private System.Windows.Forms.ComboBox comboBoxDocs;
        private System.Windows.Forms.ComboBox comboBoxPages;
        private System.Windows.Forms.Label lblPageName;
        private System.Windows.Forms.TextBox tbFieldValue;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox snippet;
        private System.Windows.Forms.Button btnComplete;
        private System.Windows.Forms.Label lblResponseStatus;
        private System.Windows.Forms.Label lblDocs;
        private System.Windows.Forms.Label lblPage;
        private System.Windows.Forms.Label lblImageFile;
        public System.Windows.Forms.TextBox tbResponseStatus;
        private System.Windows.Forms.Label lblBatchID;
        private System.Windows.Forms.TextBox tbBatchID;
        private System.Windows.Forms.Button btnGetBatchID;
        private System.Windows.Forms.TextBox tbDataFile;
        private System.Windows.Forms.TextBox tbPageImageName;
        private System.Windows.Forms.Label lblDataFile;
        private System.Windows.Forms.Button btnLoadImageFile;
        private System.Windows.Forms.ComboBox comboBoxFields;
        private System.Windows.Forms.TextBox tbFieldPosition;
        private System.Windows.Forms.GroupBox gbBatchCreation;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblResponseMessage;
        public System.Windows.Forms.TextBox tbResponseMessage;
        private System.Windows.Forms.Label lblFields;
        private System.Windows.Forms.Label lblFieldPosition;
        private System.Windows.Forms.Label lblFieldText;
        private System.Windows.Forms.Label lblSnippet;
        private System.Windows.Forms.Label lblPageFileName;
        private System.Windows.Forms.TextBox tbPageFileName;
    }
}

