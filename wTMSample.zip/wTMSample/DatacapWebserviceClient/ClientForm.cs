﻿/*Licensed Materials - Property of IBM

5725-C15

© Copyright IBM Corp. 1994, 2013 All Rights Reserved

US Government Users Restricted Rights - Use, duplication or
disclosure restricted by GSA ADP Schedule Contract with
IBM Corp.
*/

using System;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;
using System.IO;
using System.Net;

namespace Client
{
    public partial class Client : Form
    {
        private HttpStatusCode _statusCode;
        private string _responseMessageBody = "";

        public Client()
        {
            InitializeComponent();
        }


        // Check that Server Address, Application and Job Name are populated
        private bool CheckInputData(bool queueIDRequired)
        {
            string displayMsg = "";
            if (tbUri.TextLength == 0)
            {
                displayMsg += "Server Address has not been populated. Please correct" + Environment.NewLine;
            }
            if (tbApplication.TextLength == 0)
            {
                displayMsg += "Application has not been populated. Please correct" + Environment.NewLine;
            }
            if (tbJob.TextLength == 0)
            {
                displayMsg += "Job Name has not been populated. Please correct" + Environment.NewLine;
            }
            if (queueIDRequired && tbQueueID.TextLength == 0)
            {
                displayMsg += "Queue ID has not been populated. Please correct" + Environment.NewLine;
            }
            if (!string.IsNullOrEmpty(displayMsg))
                MessageBox.Show(displayMsg);
            return string.IsNullOrEmpty(displayMsg);
        }


        // Create Batch clicked
        private void BtnCreateBatchClick(object sender, EventArgs e)
        {
            if (!CheckInputData(false))
            {
                return; // Do nothing if input data is missing
            }
            // Blank out any preexisting values
            tbResponseStatus.Text = "";
            tbResponseMessage.Text = "";
            _responseMessageBody = "";

            // The HttpStatusCode enumeration contains the values of the status codes defined in RFC 2616 for HTTP 1.1
            _statusCode = new HttpStatusCode();

            // Call the CreateBatch endpoint and retrieve the new unique QID created by Taskmaster
            try
            {
                tbQueueID.Text = Endpoints.Queue.CreateBatch(tbUri.Text, tbApplication.Text, tbJob.Text, ref _statusCode, ref _responseMessageBody).ToString(CultureInfo.InvariantCulture);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception encountered while trying to create a batch" + Environment.NewLine + ex.Message);
                return;
            }

            // Record HTTP status code and response message body
            tbResponseStatus.Text = _statusCode.ToString();
            tbResponseMessage.Text = _responseMessageBody;
                
            // Enable the Browse button, Upload button and Release button
            btnBrowse.Enabled = true;
            btnUpload.Enabled = true;
            btnReleaseBatch.Enabled = true;

            if (tbResponseStatus.Text.ToUpper() == "CREATED")
            {
                // Disable Create Batch button so it cannot be run until client is reset
                btnCreateBatch.Enabled = false;
                btnGrabBatch.Enabled = false;
            }
        }

        // Browse clicked
        private void BtnBrowseClick(object sender, EventArgs e)
        {
            // Bring up folder selection UI to allow selection of a new folder
            var result = folderBrowserDialog1.ShowDialog();
            if (result != DialogResult.OK) return;
            tbImagesFolder.Text = folderBrowserDialog1.SelectedPath;
        }

        // Upload clicked
        private void BtnUpload(object sender, EventArgs e)
        {
            // Disable the images folder text field and Browse button so the values stay locked
            btnBrowse.Enabled = false;

            // Get a list of files to upload
            var localFiles = Directory.GetFiles(tbImagesFolder.Text);

            foreach (string localFileName in localFiles)
            {
                // Upload each file in the images input directory to the batch
                try
                {
                    Endpoints.Queue.UploadFile(tbUri.Text, tbApplication.Text, Convert.ToInt32(tbQueueID.Text), tbImagesFolder.Text + "\\" + Path.GetFileName(localFileName), ref _statusCode, ref _responseMessageBody);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Exception encountered while trying to upload the file" + Environment.NewLine + ex.Message);
                    return;
                }

                // Record HTTP status code and response message body
                tbResponseStatus.Text = _statusCode.ToString();
                tbResponseMessage.Text = _responseMessageBody;
            }
        }

        // Release Batch clicked
        private void BtnReleaseBatchClick(object sender, EventArgs e)
        {
            bool result;
            // Release the batch with a status of 'finished'.  The call will return true or false dependant upon the result.
            try
            {
                result = Endpoints.Queue.ReleaseBatch(tbUri.Text, tbApplication.Text, Convert.ToInt32(tbQueueID.Text), "finished", ref _statusCode, ref _responseMessageBody);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception encountered while trying to release the batch"+ Environment.NewLine + ex.Message);
                return;
            }

            // Record HTTP status code and response message body
            tbResponseStatus.Text = _statusCode.ToString();
            tbResponseMessage.Text = "ReleaseBatch has no response message body";
           
            // If successful then disable the Release Batch button until client is reset, enable GetPageFileName
            if (result.ToString(CultureInfo.InvariantCulture).ToUpper() == "TRUE")
            {
                btnReleaseBatch.Enabled = false;
                btnCreateBatch.Enabled = true;
                btnGrabBatch.Enabled = true;
                btnBrowse.Enabled = false;
                btnUpload.Enabled = false;
            }
        }


        // Get BatchID clicked
        private void BtnGetBatchIDClick(object sender, EventArgs e)
        {
            if (!CheckInputData(true))
            {
                return; // Do nothing if input data is missing
            }

            // Get the batch ID based on previously obtained QID
            try
            {
                tbBatchID.Text = Endpoints.Queue.GetBatchID(tbUri.Text, tbApplication.Text, Convert.ToInt32(tbQueueID.Text), ref _statusCode, ref _responseMessageBody).ToString(CultureInfo.InvariantCulture);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception encountered while trying to get the batch ID (ensure QID is valid)" + Environment.NewLine + ex.Message);
                return;
            }

            // Record HTTP status code and response message body
            tbResponseStatus.Text = _statusCode.ToString();
            tbResponseMessage.Text = _responseMessageBody;
        }

        // Grab Batch clicked
        private void BtnGrabBatchClick(object sender, EventArgs e)
        {
            if (!CheckInputData(true))
            {
                return; // Do nothing if input data is missing
            }

            // Get name of current page file
            if (!CheckInputData(true))
            {
                return; // Do nothing if input data is missing
            }

            try
            {
                tbPageFileName.Text = Endpoints.Queue.GetPageFileName(tbUri.Text, tbApplication.Text, Convert.ToInt32(tbQueueID.Text), ref _statusCode, ref _responseMessageBody);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception encountered while trying to get the page file name (ensure QID is valid)" + Environment.NewLine + ex.Message);
                return;
            }

            // Clear any previous wTM response information
            tbResponseStatus.Text = "";
            tbResponseMessage.Text = "";

            // Clear the comboboxes, clean the image and snippet panes
            comboBoxDocs.Items.Clear();
            comboBoxPages.Items.Clear();
            pictureBox1.Image = null;
            snippet.Image = null;

            // Parse document names from page file <Task>.xml, uses GetFile internally
            var namesOfDocs = Utility.GetNamesOfDocsInBatch(tbUri.Text, tbApplication.Text, tbQueueID.Text, Path.GetFileNameWithoutExtension(tbPageFileName.Text), ref _statusCode, ref _responseMessageBody);

            // Ensure batch has undergone external processing (document nodes are present)
            if (namesOfDocs == null || namesOfDocs.Length == 0)
            {
                tbResponseMessage.Text = "- Message from Client Project not wTM -";
                tbResponseMessage.Text += Environment.NewLine + "Batch not grabbed";
                tbResponseMessage.Text += Environment.NewLine + "No documents present in page file";
                tbResponseMessage.Text += Environment.NewLine + "The Process Task example expects at least one document with one page with one field";
            }  
            else
            {
                // Clear any previous "Refresh..." message
                tbResponseMessage.Text = "";

                // First grab the batch so we have control and it goes to a running state
                try
                {
                    if(!Endpoints.Queue.GrabBatch(tbUri.Text, tbApplication.Text, Convert.ToInt32(tbQueueID.Text), ref _statusCode, ref _responseMessageBody))
                    {
                        MessageBox.Show("Exception encountered while trying to grab the batch (ensure it is not already running)");
                        return;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Exception encountered while trying to grab the batch (ensure it is not already running)" + Environment.NewLine + ex.Message);
                    return;
                }

                // Record HTTP status code and response message body
                tbResponseStatus.Text = _statusCode.ToString();
                tbResponseMessage.Text = "GrabBatch has no response message body";

                // Populate document list
                var itemObject = new Object[namesOfDocs.Length];
                for (int i = 0; i < namesOfDocs.Length; i++)
                {
                    itemObject[i] = i.ToString(CultureInfo.InvariantCulture) + " - " + namesOfDocs[i];
                }
                comboBoxDocs.Items.AddRange(itemObject);
                comboBoxDocs.Enabled = true;
                comboBoxDocs.SelectedIndex = 0;
                comboBoxDocs.Refresh();

                // Populate selected document's page list
                GetPages(this, e);

                // Disable Create Batch and Grab Batch until client is reset
                // Enable Complete Batch so it can be clicked once finished processing
                btnGrabBatch.Enabled = false;
                btnCreateBatch.Enabled = false;
                btnComplete.Enabled = true;
            }
        }


        // Document selection changed - Load page names for selected document
        private void GetPages(object sender, EventArgs e)
        {
            tbDataFile.Text = "";
            tbPageImageName.Text = "";
            btnSave.Enabled = false;
            btnLoadImageFile.Enabled = false;

            // Clean any entries that may have been previously populated in comboxFields
            comboBoxFields.Items.Clear();
            comboBoxFields.Text = "";
            comboBoxFields.Enabled = false;
            comboBoxFields.Refresh();

            // Clean any entries that may have been previously populated into the fieldvalue and fieldposaition fields
            tbFieldValue.Text = "";
            tbFieldValue.Enabled = false;
            tbFieldPosition.Text = "";

            // Clean any entries that may have been previosuly populated into the combobox for pages
            comboBoxPages.Items.Clear();
            pictureBox1.Image = null;
            snippet.Image = null;

            // Retrieve the selected document index
            int docNum;
            int.TryParse(comboBoxDocs.SelectedIndex.ToString(CultureInfo.InvariantCulture), out docNum);
            
            // Parse page names from page file <Task>.xml, uses GetFile internally
            var namesOfPages = Utility.GetNamesOfPagesInDoc(tbUri.Text, tbApplication.Text, tbQueueID.Text, Path.GetFileNameWithoutExtension(tbPageFileName.Text), docNum, ref _statusCode, ref _responseMessageBody);

            // Populate the page names
            var itemObject = new Object[namesOfPages.Length];
            for (int i = 0; i < namesOfPages.Length; i++)
            {
                itemObject[i] = i.ToString(CultureInfo.InvariantCulture) + " - " + namesOfPages[i];
            }
            comboBoxPages.Items.AddRange(itemObject);
            comboBoxPages.Enabled = true;
            comboBoxPages.SelectedIndex = 0;

            // Disable the Save button, it will be enabled when Load Image is clicked
            btnSave.Enabled = false;
        }


        // Page selection changed - Load page's datafile name
        private void GetPageDataFileName(object sender, EventArgs e)
        {
            // Retrieve selected document and page indices
            int docNum, pageNum;
            int.TryParse(comboBoxDocs.SelectedIndex.ToString(CultureInfo.InvariantCulture), out docNum);
            int.TryParse(comboBoxPages.SelectedIndex.ToString(CultureInfo.InvariantCulture), out pageNum);

            // Get the page's datafile name (e.g. TM000001.xml), uses GetFile internally
            var nameOfFile = Utility.GetPageDataFileName(tbUri.Text, tbApplication.Text, tbQueueID.Text, Path.GetFileNameWithoutExtension(tbPageFileName.Text), docNum, pageNum, ref _statusCode, ref _responseMessageBody);
           
            // Populate the datafile name
            tbDataFile.Text = nameOfFile;
        }


        // Page selection changed - Load page's image file name
        private void GetPageImageName(object sender, EventArgs e)
        {
            // Retrieve selected document and page indices
            int docNum, pageNum;
            int.TryParse(comboBoxDocs.SelectedIndex.ToString(CultureInfo.InvariantCulture), out docNum);
            int.TryParse(comboBoxPages.SelectedIndex.ToString(CultureInfo.InvariantCulture), out pageNum);

            // Try to get the image file name (e.g. TM000001.tif) for the given page, uses GetFile internally
            var fileName = Utility.GetPageImageFileName(tbUri.Text, tbApplication.Text, tbQueueID.Text, Path.GetFileNameWithoutExtension(tbPageFileName.Text), docNum, pageNum, ref _statusCode, ref _responseMessageBody);
           
            // Populate the image file name
            tbPageImageName.Text = fileName;
            btnLoadImageFile.Enabled = true;
        }


        // Load Image clicked
        private void BtnLoadImageFileClick(object sender, EventArgs e)
        {
            // Clean out current image in picturebox
            pictureBox1.Image = null;
            pictureBox1.Refresh();

            // Parse name and extension of the image name
            string[] fileParts = tbPageImageName.Text.Split('.');
            string fileName = fileParts[0];
            string fileExt = fileParts[1];

            byte[] result;
            try
            {
                // Get the image file
                result = Endpoints.Queue.GetFile(tbUri.Text, tbApplication.Text, Convert.ToInt32(tbQueueID.Text), fileName, fileExt, ref _statusCode, ref _responseMessageBody);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception encountered while trying to get the file" + Environment.NewLine + ex.Message);
                return;
            }

            // Record HTTP status code and response message body
            tbResponseStatus.Text = _statusCode.ToString();
            tbResponseMessage.Text = "GetFile has no response message body";
            
            // Create a local copy of the image file
            using (FileStream file = new FileStream("c:\\tmp.tif", FileMode.Create, FileAccess.Write))
            {
                file.Write(result, 0, result.Length);
                file.Close();
                file.Dispose();
            }

            // Required to work around known locking issue with picturbox object
            // Read the new tmp.tif into memory and display in the picturebox
            using (FileStream newFile = new FileStream("c:\\tmp.tif", FileMode.Open, FileAccess.Read))
            {
                MemoryStream stream = new MemoryStream();
                newFile.CopyTo(stream);
                stream.Seek(0, SeekOrigin.Begin);
                pictureBox1.Image = Image.FromStream(stream);
            }

            // Load the fields associated to the page
            GetFields();
        }

        // Load page's field names
        private void GetFields()
        {
            // Clear any previous field list
            comboBoxFields.Enabled = true;
            comboBoxFields.Items.Clear();

            // Query field name(s) contained within the page's datafile, uses GetFile internally
            var namesOfFields = Utility.GetFieldList(tbUri.Text, tbApplication.Text, tbQueueID.Text, tbDataFile.Text, ref _statusCode, ref _responseMessageBody);

            // Populate field names
            if (namesOfFields != null)
            {
                var itemObject = new Object[namesOfFields.Length];
                for (int i = 0; i < namesOfFields.Length; i++)
                {
                    itemObject[i] = i.ToString(CultureInfo.InvariantCulture) + " - " + namesOfFields[i];
                }
                comboBoxFields.Items.AddRange(itemObject);
                comboBoxFields.Enabled = true;
                comboBoxFields.SelectedIndex = 0;
            }

            // Allow saving of any changes to field data only if page has 1 or more fields
            btnSave.Enabled = comboBoxFields.Items.Count != 0;
        }


        // Field selection changed - Load field's value and position
        private void GetFieldValue(object sender, EventArgs e)
        {
            int fieldNum;
            // Try to obtain current field index
            int.TryParse(comboBoxFields.SelectedIndex.ToString(CultureInfo.InvariantCulture), out fieldNum);

            // Get the field's text and position value from the datafile, uses GetFile internally
            var fieldDetails = Utility.GetFieldDetails(tbUri.Text, tbApplication.Text, tbQueueID.Text, tbDataFile.Text, fieldNum, ref _statusCode, ref _responseMessageBody);

            // Populate loaded field value and position
            tbFieldValue.Text = fieldDetails[0];
            tbFieldPosition.Text = fieldDetails[1];
            tbFieldValue.Enabled = true;
        }


        // Save clicked
        private void BtnSaveClick(object sender, EventArgs e)
        {
            int fieldNum;
            // Try to obtain current field index
            int.TryParse(comboBoxFields.SelectedIndex.ToString(CultureInfo.InvariantCulture), out fieldNum);

            // Query current field value and position
            string[] fieldDetails = new string[2];
            fieldDetails[0] = tbFieldValue.Text;
            fieldDetails[1] = tbFieldPosition.Text;
            
            // Attempt to save current field data to the datafile, uses GetFile and SetFile internally
            Utility.SetFieldDetails(tbUri.Text, tbApplication.Text, tbQueueID.Text, tbDataFile.Text, fieldNum, fieldDetails, ref _statusCode, ref _responseMessageBody);

            // Record HTTP status code and response message body
            // They should correlate to SetFile from Utility.setFieldDetails
            tbResponseStatus.Text = _statusCode.ToString();
            tbResponseMessage.Text = "SetFile has no response message body";
        }


        // Field selection changed
        private void FieldPositionTextChanged(object sender, EventArgs e)
        {
            // Ensure we have some values in here i.e. minimum is 0,0,0,0
            if (tbFieldPosition.Text.Length >= 7 && (tbFieldPosition.Text != "0,0,0,0"))
            {
                // Parse coordinates for top-left corner, and the width and height of zone
                string[] coordinates = tbFieldPosition.Text.Split(',');
                int upperX = int.Parse(coordinates[0]);
                int upperY = int.Parse(coordinates[1]);
                int width = int.Parse(coordinates[2]) - int.Parse(coordinates[0]);
                int height = int.Parse(coordinates[3]) - int.Parse(coordinates[1]);

                // Load local copy of image file
                // Create new Bitmap and Rectange based on current position data
                // Prepare Graphics object for rendering changes
                Image img = Image.FromFile("c:\\tmp.tif");
                Bitmap bmp = new Bitmap(width, height);
                bmp.SetResolution(img.HorizontalResolution, img.VerticalResolution);
                Graphics g = Graphics.FromImage(bmp);
                Rectangle r = new Rectangle(upperX, upperY, width, height);

                // Extract the new snippet
                g.DrawImage(img, 0, 0, r, GraphicsUnit.Pixel);
                g.Save();

                // Save the snippet to disk, format for display
                bmp.Save("c:\\snip.tif", System.Drawing.Imaging.ImageFormat.Tiff);
                bmp.Dispose();
                img.Dispose();
                using (FileStream newFile = new FileStream("c:\\snip.tif", FileMode.Open, FileAccess.Read))
                {
                    MemoryStream stream = new MemoryStream();
                    newFile.CopyTo(stream);
                    stream.Seek(0, SeekOrigin.Begin);
                    snippet.Image = Image.FromStream(stream);

                    if ((width > 334) || (height > 80))
                    {
                        snippet.Size = new Size(334, 80);
                        snippet.SizeMode = PictureBoxSizeMode.StretchImage;
                    }
                    else
                    {
                        snippet.Size = snippet.Image.Size;
                    }

                    snippet.Visible = true;
                    snippet.Refresh();
                }
            }
        }


        // Complete Batch clicked
        private void BtnCompleteClick(object sender, EventArgs e)
        {
            if (!CheckInputData(true))
            {
                return; // Do nothing if input data is missing
            }

            bool result = false;
            try
            {
                // Try to release the batch with 'finished' status
                result = Endpoints.Queue.ReleaseBatch(tbUri.Text, tbApplication.Text, Convert.ToInt32(tbQueueID.Text), "finished", ref _statusCode, ref _responseMessageBody);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception encountered while trying to release the batch" + Environment.NewLine + ex.Message);
                return;
            }

            // Record HTTP status code and response message body
            tbResponseStatus.Text = _statusCode.ToString();
            tbResponseMessage.Text = "ReleaseBatch has no response message body";

            if (result.ToString(CultureInfo.InvariantCulture).ToUpper() == "TRUE")
            {
                // Disable the Complete button until it is reset
                btnComplete.Enabled = false;

                // Reset batch creation back to its origins
                btnCreateBatch.Enabled = true;
                btnGetBatchID.Enabled = true;
                btnSave.Enabled = false;

                // Reset task details
                btnGrabBatch.Enabled = true;
                tbPageFileName.Enabled = false;
                tbPageFileName.Text = "";
                comboBoxDocs.Enabled = false;
                comboBoxDocs.Text = "";
                comboBoxPages.Enabled = false;
                comboBoxPages.Text = "";
                tbDataFile.Enabled = false;
                tbDataFile.Text = "";
                tbPageImageName.Enabled = false;
                tbPageImageName.Text = "";
                comboBoxFields.Enabled = false;
                comboBoxFields.Text = "";
                tbFieldValue.Enabled = false;
                tbFieldValue.Text = "";
                tbFieldPosition.Enabled = false;
                tbFieldPosition.Text = "";
                snippet.Image = null;
                pictureBox1.Image = null;
                btnLoadImageFile.Enabled = false;
            }
        }
    }
}