﻿/*Licensed Materials - Property of IBM

5725-C15

© Copyright IBM Corp. 1994, 2013 All Rights Reserved

US Government Users Restricted Rights - Use, duplication or
disclosure restricted by GSA ADP Schedule Contract with
IBM Corp.
*/

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Xml;
using System.IO;
using System.Net;

namespace Client
{
    static class Utility
    {
        // Retrieve document names from a specified page file
        public static string[] GetNamesOfDocsInBatch(String server, String application, String queueid, String filename, ref HttpStatusCode lastHttpStatusCode, ref string lastResponseMessageBody)
        {
            int docCount = 0;
            try
            {
                // Get the specified page file using GetFile
                byte[] result = Endpoints.Queue.GetFile(server, application, Convert.ToInt32(queueid), filename, "xml", ref lastHttpStatusCode, ref lastResponseMessageBody);
                
                // Build memory stream of the returned XML
                MemoryStream memoryStream = new MemoryStream();
                memoryStream.Write(result, 0, result.Length);
                memoryStream.Position = 0;

                // Find the Document nodes in the returned XML and return the Document TYPE as an array of strings
                XmlDocument doc = new XmlDocument();
                doc.Load(memoryStream);
                XmlNode batchRoot = doc.LastChild;
                XmlNodeList docNodeList = batchRoot.SelectNodes("D");
                if (docNodeList != null)
                {
                    string[] docNames = new string[docNodeList.Count];

                    // Parse document data
                    foreach (XmlNode dNode in docNodeList)
                    {
                        if (dNode.HasChildNodes)
                        {
                            foreach (XmlNode dvNode in dNode)
                            {
                                if (dvNode.Attributes != null && dvNode.Attributes[0].Value == "TYPE")
                                {
                                    docNames[docCount] = dvNode.InnerText;
                                    docCount++;
                                }
                            }
                        }
                    }

                    // Return the document names
                    return docNames;
                }
            }
            catch
            {
                return null;
            }
            return null;
        }


        // Retrieve page names from a specified page file
        public static string[] GetNamesOfPagesInDoc(String server, String application, String queueid, String filename, int docNum, ref HttpStatusCode lastHttpStatusCode, ref string lastResponseMessageBody)
        {
            int pageCount = 0;
            try
            {
                // Get the specified page file using GetFile
                byte[] result = Endpoints.Queue.GetFile(server, application, Convert.ToInt32(queueid), filename, "xml", ref lastHttpStatusCode, ref lastResponseMessageBody);
                
                // Build memory stream of the returned XML
                MemoryStream memoryStream = new MemoryStream();
                memoryStream.Write(result, 0, result.Length);
                memoryStream.Position = 0;

                // Find the names of a page nodes under a given document node from the returned XML and return the value as a string array
                XmlDocument doc = new XmlDocument();
                doc.Load(memoryStream);
                XmlNode batchRoot = doc.LastChild;
                XmlNodeList docNodeList = batchRoot.SelectNodes("D");
                if (docNodeList != null)
                {
                    XmlNodeList pageNodeList = docNodeList[docNum].SelectNodes("P");
                    if (pageNodeList != null)
                    {
                        string[] pageNames = new string[pageNodeList.Count];

                        // Parse page data
                        foreach (XmlNode pageNode in pageNodeList)
                        {
                            if (pageNode.Attributes != null)
                            {
                                pageNames[pageCount] = pageNode.Attributes[0].Value;

                                foreach (XmlNode pageInfo in pageNode)
                                {
                                    if (pageInfo.Attributes != null && pageInfo.Attributes[0].Value == "TYPE")
                                    {
                                        pageNames[pageCount] = pageNames[pageCount] + " - " + pageInfo.InnerText;
                                    }
                                }
                            }
                            pageCount++;
                        }

                        // Return the page names
                        return pageNames;
                    }
                }
            }
            catch
            {
                return null;
            }
            return null;
        }


        // Get a page's datafile name
        public static string GetPageDataFileName(String server, String application, String queueid, String filename, int docNum, int pageNum, ref HttpStatusCode lastHttpStatusCode, ref string lastResponseMessageBody)
        {
            try
            {
                // Get the specified page file using GetFile
                byte[] result = Endpoints.Queue.GetFile(server, application, Convert.ToInt32(queueid), filename, "xml", ref lastHttpStatusCode, ref lastResponseMessageBody);
                
                // Build memory stream of the returned xml
                MemoryStream memoryStream = new MemoryStream();
                memoryStream.Write(result, 0, result.Length);
                memoryStream.Position = 0;

                // Find the filename of a specific page node from a given document node and subsequent page node from the returned XML 
                XmlDocument doc = new XmlDocument();
                doc.Load(memoryStream);
                XmlNode batchRoot = doc.LastChild;
                XmlNodeList docNodeList = batchRoot.SelectNodes("D");
                if (docNodeList != null)
                {
                    XmlNodeList pageNodeList = docNodeList[docNum].SelectNodes("P");
                    if (pageNodeList != null)
                    {
                        XmlNode pageNode = pageNodeList[pageNum];

                        // Return the datafile name with '.xml' appended to end
                        if (pageNode.Attributes != null) return pageNode.Attributes[0].Value + ".xml";
                    }
                }
            }
            catch
            {
                return null;
            }
            return null;
        }


        // Get a page's image file (IMAGEFILE) name
        public static string GetPageImageFileName(String server, String application, String queueid, String filename, int docNum, int pageNum, ref HttpStatusCode lastHttpStatusCode, ref string lastResponseMessageBody)
        {
            try
            {
                // Get the specified page file using GetFile
                byte[] result = Endpoints.Queue.GetFile(server, application, Convert.ToInt32(queueid), filename, "xml", ref lastHttpStatusCode, ref lastResponseMessageBody);

                // Build memory stream of the returned xml
                MemoryStream memoryStream = new MemoryStream();
                memoryStream.Write(result, 0, result.Length);
                memoryStream.Position = 0;

                // Find the filename of a specific page node from a given document node and subsequent page node from the returned XML 
                // and return the value as a string appended with .xml
                XmlDocument doc = new XmlDocument();
                doc.Load(memoryStream);
                XmlNode batchRoot = doc.LastChild;
                XmlNodeList docNodeList = batchRoot.SelectNodes("D");
                if (docNodeList != null)
                {
                    XmlNodeList pageNodeList = docNodeList[docNum].SelectNodes("P");
                    if (pageNodeList != null)
                    {
                        XmlNode pageNode = pageNodeList[pageNum];
                        XmlNodeList pageNodeDetails = pageNode.ChildNodes;

                        // Attempt to find IMAGEFILE
                        foreach (XmlNode pageNodeDetail in pageNodeDetails)
                        {
                            // If IMAGEFILE found, get the value and return it 
                            if (pageNodeDetail.Attributes != null && pageNodeDetail.Attributes[0].Value == "IMAGEFILE")
                            {
                                return pageNodeDetail.InnerText;
                            }
                        }
                    }
                }
                return null;
            }
            catch
            {
                return null;
            }
        }


        // Get a list of fields for a given page
        public static string[] GetFieldList(String server, String application, String queueid, String filename, ref HttpStatusCode lastHttpStatusCode, ref string lastResponseMessageBody)
        {
            int fieldCount = 0;
            try
            {
                string[] fileParts = filename.Split('.');
                string fileName = fileParts[0];
                string fileExt = fileParts[1];

                // Get the specified datafile using GetFile
                byte[] result = Endpoints.Queue.GetFile(server, application, Convert.ToInt32(queueid), fileName, fileExt, ref lastHttpStatusCode, ref lastResponseMessageBody);

                // build memory stream of the returned xml
                MemoryStream memoryStream = new MemoryStream();
                memoryStream.Write(result, 0, result.Length);
                memoryStream.Position = 0;

                // Find the number of Document nodes in the returned XML and return the value as an integer
                XmlDocument doc = new XmlDocument();
                doc.Load(memoryStream);
                XmlNode batchRoot = doc.LastChild;
                XmlNodeList fieldNodeList = batchRoot.SelectNodes("F");
                if (fieldNodeList != null)
                {
                    string[] fieldNames = new string[fieldNodeList.Count];

                    foreach (XmlNode fieldNode in fieldNodeList)
                    {
                        // get the field name from id i.e. <F id="To">
                        if (fieldNode.Attributes != null) fieldNames[fieldCount] = fieldNode.Attributes[0].Value;
                        fieldCount++;
                    }

                    // Return the field names
                    return fieldNames;
                }
            }
            catch
            {
                return null;
            }
            return null;
        }


        // Get field data from a datafile
        public static string[] GetFieldDetails(String server, String application, String queueid, String filename, int fieldNum, ref HttpStatusCode lastHttpStatusCode, ref string lastResponseMessageBody)
        {
            // String array to hold the value of 
            // 1) Field Value
            // 2) Field Position
            string[] fieldDetails = new string[2];

            try
            {
                string[] fileParts = filename.Split('.');
                string fileName = fileParts[0];
                string fileExt = fileParts[1];

                string fieldValue = "";
                string fieldPosition = "";

                // Get the specified datafile using GetFile
                byte[] result = Endpoints.Queue.GetFile(server, application, Convert.ToInt32(queueid), fileName, fileExt, ref lastHttpStatusCode, ref lastResponseMessageBody);

                // Build memory stream of the returned xml
                MemoryStream memoryStream = new MemoryStream();
                memoryStream.Write(result, 0, result.Length);
                memoryStream.Position = 0;

                // Find the number of Document nodes in the returned XML and return the value as an integer
                XmlDocument doc = new XmlDocument();
                doc.Load(memoryStream);
                XmlNode batchRoot = doc.LastChild;
                XmlNodeList fieldNodeList = batchRoot.SelectNodes("F");
                if (fieldNodeList != null)
                {
                    XmlNode fieldNode = fieldNodeList[fieldNum]; 

                    // Get the field's text value
                    foreach (XmlNode fieldAttr in fieldNode)
                    {
                        if (fieldAttr.Attributes != null && fieldAttr.Attributes[0].Name == "cn")
                        {
                            fieldValue = fieldValue + Convert.ToChar(Convert.ToInt16(fieldAttr.InnerText)).ToString(CultureInfo.InvariantCulture);
                        }
                   
                    }

                    // Get character confidence values, not used in this client demo
                    /*
                foreach (XmlNode fieldAttr in fieldNode)
                {
                    if (fieldAttr.Attributes[0].Value == "cn")
                    {
                        fieldConfidence = fieldConfidence + ":" + fieldAttr.Attributes[0].Value;
                    }

                }
                 */

                    // Get the field's zone position
                    foreach (XmlNode fieldAttr in fieldNode)
                    {
                        if (fieldAttr.Attributes != null && fieldAttr.Attributes[0].Value == "Position")
                        {
                            fieldPosition = fieldAttr.InnerText;
                        }
                    }
                }

                // Return field data
                fieldDetails[0] = fieldValue;
                fieldDetails[1] = fieldPosition; 
                return fieldDetails;
            }
            catch
            {
                return null;
            }
        }


        // Save field data to datafile
        public static void SetFieldDetails(String server, String application, String queueid, String filename, int fieldNum, string[] fieldValues, ref HttpStatusCode lastHttpStatusCode, ref string lastResponseMessageBody)
        {
            string[] fileParts = filename.Split('.');
            string fileName = fileParts[0];
            string fileExt = fileParts[1];

            // Get the specified datafile using GetFile
            byte[] result = Endpoints.Queue.GetFile(server, application, Convert.ToInt32(queueid), fileName, fileExt, ref lastHttpStatusCode, ref lastResponseMessageBody);

            // Build memory stream of the returned xml
            MemoryStream memoryStream = new MemoryStream();
            memoryStream.Write(result, 0, result.Length);
            memoryStream.Position = 0;

            // Find the number of Document nodes in the returned XML and return the value as an integer
            XmlDocument doc = new XmlDocument();
            doc.Load(memoryStream);

            XmlNode batchRoot = doc.LastChild;
            XmlNodeList fieldNodeList = batchRoot.SelectNodes("F");
            if (fieldNodeList != null)
            {
                XmlNode fieldNode = fieldNodeList[fieldNum];
                XmlNodeList fieldList =  fieldNode.ChildNodes;
                List<XmlNode> toRemove = new List<XmlNode>();

                // Delete the original values from the field
                foreach (XmlNode node in fieldList)
                {
                    if (node.Attributes != null && node.Attributes[0].Name == "cn")
                    {
                        toRemove.Add(node);
                    }
                }
                foreach (XmlNode xmlElement in toRemove)
                {
                    XmlNode node = xmlElement.ParentNode;
                    if (node != null) node.RemoveChild(xmlElement);
                }

                // Now add the new values
                foreach (byte b in System.Text.Encoding.UTF8.GetBytes(fieldValues[0].ToCharArray()))
                {
                    XmlAttribute confAttr = doc.CreateAttribute("cn");
                    confAttr.Value = "10";
                    XmlAttribute posAttr = doc.CreateAttribute("cr");
                    posAttr.Value = "0,0,0,0";

                    XmlNode newElem = doc.CreateNode("element", "c", "");
                    newElem.InnerText = b.ToString(CultureInfo.InvariantCulture);
                    if (newElem.Attributes != null)
                    {
                        newElem.Attributes.Append(confAttr);
                        newElem.Attributes.Append(posAttr);
                    }

                    fieldNode.AppendChild(newElem);
                }
            }

            doc.Save("c:\\data.xml");
            // Save the datafile using SetFile
            Endpoints.Queue.SetFile(server, application, Convert.ToInt32(queueid), "c:\\data.xml", fileName, fileExt, ref lastHttpStatusCode, ref lastResponseMessageBody);
        }      
    }
}