﻿/*Licensed Materials - Property of IBM

5725-C15

© Copyright IBM Corp. 1994, 2013 All Rights Reserved

US Government Users Restricted Rights - Use, duplication or
disclosure restricted by GSA ADP Schedule Contract with
IBM Corp.
*/

using System.Net;

namespace Endpoints
{
    public static partial class Queue
    {
        // Attempt to place a batch into 'running' status
        // Return true or false if request succeeds or fails
        public static bool GrabBatch(string host, string application, int queueID, ref HttpStatusCode lastHttpStatusCode, ref string lastResponseMessageBody)
        {
            // Generate Uri for request
            var relativePath = "/Queue/GrabBatch/" + application + "/" + queueID;
            var fullUri = host + relativePath;
            System.Diagnostics.Debug.WriteLine("GrabBatch URL: " + fullUri);

            // Create a PUT request
            var request = (HttpWebRequest)WebRequest.Create(fullUri);
            request.Method = "PUT";
            request.ContentLength = 0;

            bool requestSent = false;
            // Send grab request to wTM
            using (var response = request.GetResponse())
            {
                // Record the HTTP response status
                var httpResponse = (HttpWebResponse)response;
                System.Diagnostics.Debug.WriteLine(httpResponse.StatusCode.ToString());
                lastHttpStatusCode = httpResponse.StatusCode;

                // Batch should be grabbed if returned status is OK (200)
                requestSent = httpResponse.StatusCode == HttpStatusCode.OK;
            }

            // GrabBatch has no response message
            lastResponseMessageBody = "";
            return requestSent;
        }
    }
}