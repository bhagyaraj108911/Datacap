﻿/*Licensed Materials - Property of IBM

5725-C15

© Copyright IBM Corp. 1994, 2013 All Rights Reserved

US Government Users Restricted Rights - Use, duplication or
disclosure restricted by GSA ADP Schedule Contract with
IBM Corp.
*/

using System.Net;

namespace Endpoints
{
    public static partial class Queue
    {
        // Attempt to release a batch with desired status
        // Return true or false if request succeeds or fails
        public static bool ReleaseBatch(string host, string application, int queueID, string status, ref HttpStatusCode lastHttpStatusCode, ref string lastResponseMessageBody)
        {
            // Generate Uri for request
            var relativePath = "/Queue/ReleaseBatch/" + application + "/" + queueID + "/" + status;
            var fullUri = host + relativePath;
            System.Diagnostics.Debug.WriteLine("ReleaseBatch URL: " + fullUri);

            // Create a PUT request
            var request = (HttpWebRequest)WebRequest.Create(fullUri);
            request.Method = "PUT";
            request.ContentLength = 0;

            bool requestSent = false;
            // Send release request to wTM
            using (var response = request.GetResponse())
            {
                // Record the HTTP response status
                var httpResponse = (HttpWebResponse)response;
                System.Diagnostics.Debug.WriteLine(httpResponse.StatusCode.ToString());
                lastHttpStatusCode = httpResponse.StatusCode;

                // Batch should be released if returned status is OK (200)
                requestSent = httpResponse.StatusCode == HttpStatusCode.OK;
            }

            // ReleaseBatch has no response message
            lastResponseMessageBody = "";
            return requestSent;
        }
    }
}