﻿/*Licensed Materials - Property of IBM

5725-C15

© Copyright IBM Corp. 1994, 2013 All Rights Reserved

US Government Users Restricted Rights - Use, duplication or
disclosure restricted by GSA ADP Schedule Contract with
IBM Corp.
*/

using System.IO;
using System.Net;
using System.Xml.Linq;

namespace Endpoints
{
    public static partial class Queue
    {
        // Get a batch's attributes (batch ID, job name, QID, status and task)
        // Return attributes XML or null if request succeeds or fails
        public static string GetBatchAttributes(string host, string application, int queueID, ref HttpStatusCode lastHttpStatusCode, ref string lastResponseMessageBody)
        {
            // Generate Uri for request
            var relativePath = "/Queue/GetBatchAttributes/" + application + "/" + queueID;
            var fullUri = host + relativePath;
            System.Diagnostics.Debug.WriteLine("GetBatchAttributes URL: " + fullUri);

            // Create a GET request
            var request = (HttpWebRequest)WebRequest.Create(fullUri);
            request.Method = "GET";
            request.Accept = "text/xml";
            request.ContentLength = 0;

            XDocument xDocument = null;
            string batchAttributes = null;
            // Query wTM for the attributes
            using (var response = request.GetResponse())
            {
                // Record the HTTP response status
                var httpResponse = (HttpWebResponse)response;
                System.Diagnostics.Debug.WriteLine(httpResponse.StatusCode.ToString());
                lastHttpStatusCode = httpResponse.StatusCode;

                var responseStream = response.GetResponseStream();
                // Read the response message from wTM if it responded with OK (200) status
                if (httpResponse.StatusCode == HttpStatusCode.OK && responseStream != null)
                {
                    using (var streamReader = new StreamReader(responseStream))
                    {
                        // Create an XML representation of response message
                        xDocument = XDocument.Parse(streamReader.ReadToEnd());
                        if (xDocument.Root != null)
                        {
                            // Batch attributes are represented by the entire returned XML
                            var batchAttributesNode = xDocument.Root;
                            batchAttributes = batchAttributesNode.ToString(SaveOptions.None);

                            // Fetch batch ID from batchAttributes node
                            var batchIDNode = batchAttributesNode.Element("batchId");
                            System.Diagnostics.Debug.WriteLine(batchIDNode != null ? "Batch ID: " + batchIDNode.Value : "Batch ID: null");

                            // Fetch job name from batchAttributes node
                            var jobNameNode = batchAttributesNode.Element("job");
                            System.Diagnostics.Debug.WriteLine(jobNameNode != null ? "Job: " + jobNameNode.Value : "Job: null");

                            // Fetch QID from batchAttributes node
                            var qIDNode = batchAttributesNode.Element("queueId");
                            System.Diagnostics.Debug.WriteLine(qIDNode != null ? "QID: " + qIDNode.Value : "QID: null");

                            // Fetch status from batchAttributes node
                            var statusNode = batchAttributesNode.Element("status");
                            System.Diagnostics.Debug.WriteLine(statusNode != null ? "Status: " + statusNode.Value : "Status: null");

                            // Fetch task from batchAttributes node
                            var taskNode = batchAttributesNode.Element("task");
                            System.Diagnostics.Debug.WriteLine(taskNode != null ? "Task: " + taskNode.Value : "Task: null");
                        }
                    }
                }
            }

            // Record the response if present, else store an empty string
            lastResponseMessageBody = xDocument != null ? xDocument.ToString(SaveOptions.None) : "";
            return batchAttributes;
        }
    }
}