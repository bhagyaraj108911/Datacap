﻿/*Licensed Materials - Property of IBM

5725-C15

© Copyright IBM Corp. 1994, 2013 All Rights Reserved

US Government Users Restricted Rights - Use, duplication or
disclosure restricted by GSA ADP Schedule Contract with
IBM Corp.
*/

using System.IO;
using System.Net;
using System.Xml;
using System.Xml.Linq;

namespace Endpoints
{
    public static partial class Queue
    {
        // Create a new batch
        // Return the created batch's QID or -1 if request succeeds or fails
        public static int CreateBatch(string host, string application, string job, ref HttpStatusCode lastHttpStatusCode, ref string lastResponseMessageBody)
        {
            // Generate Uri for request
            var relativePath = "/Queue/CreateBatch";
            var fullUri = host + relativePath;
            System.Diagnostics.Debug.WriteLine("CreateBatch URL: " + fullUri);

            // Create a POST request
            var request = (HttpWebRequest)WebRequest.Create(fullUri);
            request.ContentType = "application/xml";
            request.Method = "POST";
            request.Accept = "text/xml";
            
            // Generate an XML document with createBatchAttributes at its root
            // Add application name, batch name, and job name underneath createBatchAttributes
            var xmlDocument = new XmlDocument();
            var documentNode = xmlDocument.AppendChild(xmlDocument.CreateElement("createBatchAttributes"));
            var applicationNode = documentNode.AppendChild(xmlDocument.CreateElement("application"));
            applicationNode.InnerText = application;
            var batchFolderNode = documentNode.AppendChild(xmlDocument.CreateElement("batchFolder"));
            var jobNode = documentNode.AppendChild(xmlDocument.CreateElement("job"));
            jobNode.InnerText = job;


            // Case 1: Only specify application and job names as above, batchFolder is empty
            //         Taskmaster manages the batch folder and page file

            // Case 2: Manage the page file manually; batch ID in DCO is always updated by Taskmaster
            //         Image file for TM000001 to be subsequently uploaded as TM000001.tif using SetFile
            //         Exclude the page node if subsequently uploading to the batch using UploadFile
            /*var pageFileNode = documentNode.AppendChild(xmlDocument.CreateElement("pageFile"));
            pageFileNode.InnerXml = "<B id=\"\">" +
                                      "<V n=\"STATUS\">0</V>" +
                                      "<V n=\"TYPE\">TravelDocs</V>" +
                                      "<P id=\"TM000001\">" +
                                        "<V n=\"TYPE\">Other</V>" +
                                        "<V n=\"STATUS\">49</V>" +
                                        "<V n=\"IMAGEFILE\">TM000001.tif</V>" +
                                      "</P>" +
                                    "</B>";*/

            // Case 3a: Manage batch folder and page file manually
            //          Same as above, but set batchFolder's text to a preexisting batch directory
            //          e.g. batchFolderNode.InnerText = @"C:\Datacap\FastApp\batches\wTM_Example";

            // Case 3b: Manage batch folder and page file manually
            //          Specified batch folder and page file must previously exist
            /*batchFolderNode.InnerText = @"C:\Datacap\FastApp\batches\wTM_Example";
            var pageFileNode = documentNode.AppendChild(xmlDocument.CreateElement("pageFile"));
            var pageFileInnerNode = pageFileNode.AppendChild(xmlDocument.CreateElement("file"));
            pageFileInnerNode.InnerText = "wtm.xml";*/


            // Send create request to wTM
            using (var requestStream = request.GetRequestStream())
            {
                var requestBytes = System.Text.Encoding.ASCII.GetBytes(documentNode.OuterXml);
                requestStream.Write(requestBytes, 0, requestBytes.Length);
                requestStream.Close();
            }

            XDocument xDocument=null;
            int queueId = -1;
            // Get response to confirm batch was created successfully
            using (var response = request.GetResponse())
            {
                // Record the HTTP response status
                var httpResponse = (HttpWebResponse)response;
                System.Diagnostics.Debug.WriteLine(httpResponse.StatusCode.ToString());
                lastHttpStatusCode = httpResponse.StatusCode;

                var responseStream = response.GetResponseStream();
                // Read the response message from wTM if it responded with Created (201) status
                if (httpResponse.StatusCode == HttpStatusCode.Created && responseStream != null)
                {
                    using (var streamReader = new StreamReader(responseStream))
                    {
                        // Create an XML representation of response message
                        xDocument = XDocument.Parse(streamReader.ReadToEnd());
                        if (xDocument.Root != null)
                        {
                            // Log various attributes returned by response if present: batch ID, job name, QID, status and task
                            System.Diagnostics.Debug.WriteLine(xDocument.Root.Element("batchId") != null ? "Batch ID: " + xDocument.Root.Element("batchId").Value : "Batch ID: null");
                            System.Diagnostics.Debug.WriteLine(xDocument.Root.Element("job") != null ? "Job: " + xDocument.Root.Element("job").Value : "Job: null");
                            if (xDocument.Root.Element("queueId") != null)
                            {
                                queueId = int.Parse(xDocument.Root.Element("queueId").Value);
                                System.Diagnostics.Debug.WriteLine("Queue ID: " + xDocument.Root.Element("queueId").Value);
                            }
                            System.Diagnostics.Debug.WriteLine(xDocument.Root.Element("status") != null ? "Status: " + xDocument.Root.Element("status").Value : "status: null");
                            System.Diagnostics.Debug.WriteLine(xDocument.Root.Element("task") != null ? "Task: " + xDocument.Root.Element("task").Value : "Task: null");
                        }
                    }
                }
            }

            // Record the response if present, else store an empty string
            lastResponseMessageBody = xDocument!=null ? xDocument.ToString(SaveOptions.None) : "";
            return queueId;
        }
    }
}
