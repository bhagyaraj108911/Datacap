﻿/*Licensed Materials - Property of IBM

5725-C15

© Copyright IBM Corp. 1994, 2013 All Rights Reserved

US Government Users Restricted Rights - Use, duplication or
disclosure restricted by GSA ADP Schedule Contract with
IBM Corp.
*/

using System.Net;

namespace Endpoints
{
    public static partial class Queue
    {
        // Set the page file name for a batch
        // Return true or false if request succeeds or fails
        public static bool SetPageFileName(string host, string application, int queueID, string fileName, string fileExt, ref HttpStatusCode lastHttpStatusCode, ref string lastResponseMessageBody)
        {
            // Generate Uri for request
            var relativePath = "/Queue/SetPageFileName/" + application + "/" + queueID + "/" + fileName + "/" + fileExt;
            var fullUri = host + relativePath;
            System.Diagnostics.Debug.WriteLine("SetPageFileName URL: " + fullUri);

            // Create a PUT request
            var request = (HttpWebRequest)WebRequest.Create(fullUri);
            request.Method = "PUT";
            request.ContentLength = 0;

            // Send set request to wTM
            bool requestSent = false;
            using (var response = request.GetResponse())
            {
                // Record the HTTP response status
                var httpResponse = (HttpWebResponse)response;
                System.Diagnostics.Debug.WriteLine(httpResponse.StatusCode.ToString());
                lastHttpStatusCode = httpResponse.StatusCode;

                // Page file name should be set if returned status is OK (200)
                requestSent = httpResponse.StatusCode == HttpStatusCode.OK;
            }

            // SetPageFileName has no response message
            lastResponseMessageBody = "";
            return requestSent;
        }
    }
}