﻿/*Licensed Materials - Property of IBM

5725-C15

© Copyright IBM Corp. 1994, 2013 All Rights Reserved

US Government Users Restricted Rights - Use, duplication or
disclosure restricted by GSA ADP Schedule Contract with
IBM Corp.
*/

using System.IO;
using System.Net;
using System.Xml.Linq;

namespace Endpoints
{
    public static partial class Queue
    {
        // Get the batch ID for a given QID
        // Return batch ID or null if request succeeds or fails
        public static string GetBatchID(string host, string application, int queueID, ref HttpStatusCode lastHttpStatusCode, ref string lastResponseMessageBody)
        {
            // Generate Uri for request
            var relativePath = "/Queue/GetBatchID/" + application + "/" + queueID;
            var fullUri = host + relativePath;
            System.Diagnostics.Debug.WriteLine("GetBatchID URL: " + fullUri);

            // Create a GET request
            var request = (HttpWebRequest)WebRequest.Create(fullUri);
            request.Method = "GET";
            request.Accept = "text/xml";
            request.ContentLength = 0;

            XDocument xDocument = null;
            string batchID = null;
            // Query wTM for the batch ID
            using (var response = request.GetResponse())
            {
                // Record the HTTP response status
                var httpResponse = (HttpWebResponse)response;
                System.Diagnostics.Debug.WriteLine(httpResponse.StatusCode.ToString());
                lastHttpStatusCode = httpResponse.StatusCode;

                var responseStream = response.GetResponseStream();
                // Read the response message from wTM if it responded with OK (200) status
                if (httpResponse.StatusCode == HttpStatusCode.OK && responseStream != null)
                {
                    using (var streamReader = new StreamReader(responseStream))
                    {
                        // Create an XML representation of response message
                        xDocument = XDocument.Parse(streamReader.ReadToEnd());
                        if (xDocument.Root != null)
                        {
                            // Fetch the batch ID located in root node of the XML
                            batchID = xDocument.Root.Value;
                            System.Diagnostics.Debug.WriteLine("Batch ID: " + batchID);
                        }
                    }
                }
            }

            // Record the response if present, else store an empty string
            lastResponseMessageBody = xDocument != null ? xDocument.ToString(SaveOptions.None) : "";
            return batchID;
        }
    }
}