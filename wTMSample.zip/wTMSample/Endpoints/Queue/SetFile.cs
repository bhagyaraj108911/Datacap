﻿/*Licensed Materials - Property of IBM

5725-C15

© Copyright IBM Corp. 1994, 2013 All Rights Reserved

US Government Users Restricted Rights - Use, duplication or
disclosure restricted by GSA ADP Schedule Contract with
IBM Corp.
*/

using System;
using System.IO;
using System.Net;

namespace Endpoints
{
    public static partial class Queue
    {
        // Add a file to a batch, but do not insert a page node into its page file
        // Return true or false if request succeeds or fails
        public static bool SetFile(string host, string application, int queueID, string filePath, string fileName, string fileExt, ref HttpStatusCode lastHttpStatusCode, ref string lastResponseMessageBody)
        {
            // Generate Uri for request
            var relativePath = "/Queue/SetFile/" + application + "/" + queueID + "/" + fileName + "/" + fileExt;
            var fullUri = host + relativePath;
            System.Diagnostics.Debug.WriteLine("SetFile URL: " + fullUri);

            // Create a POST request
            // File to be submitted as form data that includes start and end boundaries
            // Guid is a unique value that will not be repeated within the actual file contents
            var request = (HttpWebRequest)WebRequest.Create(fullUri);
            string boundary = "---------------------------" + new Guid();
            request.ContentType = "multipart/form-data; boundary=" + boundary;
            request.Method = "POST";

            // Open request stream to upload data
            using (var requestStream = request.GetRequestStream())
            {
                // Upload start boundary of part
                byte[] boundarybytes = System.Text.Encoding.ASCII.GetBytes("\r\n--" + boundary + "\r\n");
                requestStream.Write(boundarybytes, 0, boundarybytes.Length);

                // Upload content disposition, including file name
                var fileInfo = new FileInfo(filePath);
                string formitem = string.Format("Content-Disposition: form-data; name=\"file\"; filename=\"{0}\"\r\n\r\n", fileInfo.Name);
                byte[] formitembytes = System.Text.Encoding.UTF8.GetBytes(formitem);
                requestStream.Write(formitembytes, 0, formitembytes.Length);

                // Upload the file in 4KB chunks
                var fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                var buffer = new byte[4096];
                int bytesRead;
                while ((bytesRead = fileStream.Read(buffer, 0, buffer.Length)) != 0)
                {
                    requestStream.Write(buffer, 0, bytesRead);
                }
                fileStream.Close();

                // Upload end boundary of part
                byte[] trailer = System.Text.Encoding.ASCII.GetBytes("\r\n--" + boundary + "--\r\n");
                requestStream.Write(trailer, 0, trailer.Length);
                requestStream.Close();
            }

            bool fileUploaded = false;
            // Get response to confirm that file was uploaded successfully
            using (var response = request.GetResponse())
            {
                // Record the HTTP response status
                var httpResponse = (HttpWebResponse)response;
                System.Diagnostics.Debug.WriteLine(httpResponse.StatusCode.ToString());
                lastHttpStatusCode = httpResponse.StatusCode;

                // File should be uploaded if returned status is Created (201)
                fileUploaded = httpResponse.StatusCode == HttpStatusCode.Created;
            }

            // SetFile has no response message
            lastResponseMessageBody = "";
            return fileUploaded;
        }
    }
}