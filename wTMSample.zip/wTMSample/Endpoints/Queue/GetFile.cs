﻿/*Licensed Materials - Property of IBM

5725-C15

© Copyright IBM Corp. 1994, 2013 All Rights Reserved

US Government Users Restricted Rights - Use, duplication or
disclosure restricted by GSA ADP Schedule Contract with
IBM Corp.
*/

using System.IO;
using System.Net;

namespace Endpoints
{
    public static partial class Queue
    {
        // Get a file from a batch
        // Return file in byte array or null if request succeeds or fails
        public static byte[] GetFile(string host, string application, int queueID, string fileName, string fileExt, ref HttpStatusCode lastHttpStatusCode, ref string lastResponseMessageBody)
        {
            // Generate Uri for request
            var relativePath = "/Queue/GetFile/" + application + "/" + queueID + "/" + fileName + "/" + fileExt;
            var fullUri = host + relativePath;
            System.Diagnostics.Debug.WriteLine("GetFile URL: " + fullUri);

            // Create a GET request
            // Accept the returned file in binary format
            var request = (HttpWebRequest)WebRequest.Create(fullUri);
            request.Method = "GET";
            request.Accept = "application/octet-stream";
            request.ContentLength = 0;

            byte[] requestedFile = null;
            // Query wTM for the file
            using (var response = request.GetResponse())
            {
                // Record the HTTP response status
                var httpResponse = (HttpWebResponse)response;
                System.Diagnostics.Debug.WriteLine(httpResponse.StatusCode.ToString());
                lastHttpStatusCode = httpResponse.StatusCode;

                var responseStream = response.GetResponseStream();
                // Fetch the file from wTM if it responded with OK (200) status
                if (httpResponse.StatusCode == HttpStatusCode.OK && responseStream != null)
                {
                    using (var memoryStream = new MemoryStream())
                    {
                        // Read the file into a memory stream in 4KB chunks
                        int countRead = 1;
                        byte[] buffer = new byte[4096];
                        while (responseStream.CanRead && countRead > 0)
                        {
                            countRead = responseStream.Read(buffer, 0, 4096);
                            memoryStream.Write(buffer, 0, countRead);
                        }

                        // Store the file as a byte array when completely read
                        requestedFile = memoryStream.ToArray();
                        System.Diagnostics.Debug.WriteLine("Bytes read: " + requestedFile.Length);
                    }
                }
            }

            // GetFile has no response message
            lastResponseMessageBody = "";
            return requestedFile;
        }
    }
}